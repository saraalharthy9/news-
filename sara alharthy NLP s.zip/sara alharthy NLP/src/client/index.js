// js files
import { handleSubmit } from './js/formHandler'
import { checkForName } from './js/nameChecker'

const form = document.getElementById('urlForm');
form.addEventListener('submit', handleSubmit);

const nameForm = document.getElementById('nameForm');
nameForm.addEventListener('submit', function(event) { 
    event.preventDefault(); 
    const inputText = document.getElementById('name').value; 
    checkForName(inputText); 
});

// sass files
import './styles/resets.scss'
import './styles/base.scss'
import './styles/footer.scss'
import './styles/form.scss'
import './styles/header.scss'

