//Make fnction that check url and import it here
function isUrlValid(userInput) {
  try {
    new URL(userInput);
    return true;
  } catch (error) {
    return false;
  }
}

export const handleSubmit = (event) => {
  event.preventDefault();

  // Get the URL from the input field
  const userUrl = document.getElementById('name').value;
  // Check if the URL is valid
  if (isUrlValid(userUrl)) {
    // If the URL is valid, send it to the server
    sendUrltoserver('/api', { url: userUrl })
      .then(function (res) {
        console.log('Server Respone: ', res);

        document.getElementById('polarity').innerHTML =
          'Polarity: ' + res.score_tag;
        document.getElementById('agreement').innerHTML =
          'Agreement: ' + res.agreement;
        document.getElementById('subjectivity').innerHTML =
          'Subjectivity: ' + res.subjectivity;
        document.getElementById('confidence').innerHTML =
          'Confidence: ' + res.confidence;
        document.getElementById('irony').innerHTML = 'Irony: ' + res.irony;
      })
      .catch(function (error) {
        console.error('Error:', error);
        alert('Error processing your request. Please try again.');
      });
  } else {
    alert('please enter valid url');
  }
};

// Function to send data to the server
const sendUrltoserver = async (url = '', data = {}) => {
  console.log('Analyzing: ', data);
  try {
    const response = await fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    return response.json();
  } catch (error) {
    throw error;
  }
};
