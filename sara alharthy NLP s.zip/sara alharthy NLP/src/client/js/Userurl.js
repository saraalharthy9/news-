export const isUrlValid = (userInput) => {
  try {
    new URL(userInput);
    return true;
  } catch (error) {
    return false;
  }
};
