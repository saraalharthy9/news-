const form = document.getElementById('urlForm');

form.addEventListener('submit', handleSubmit);
